using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Orion
{

    public class Manager : MonoBehaviour
    {
        public Timer myTimer;
        public Movements myMovements;

        public bool perfect;
        public bool good;
        public bool bad;

        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        { }

    }
}


