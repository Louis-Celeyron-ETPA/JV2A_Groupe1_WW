public enum MinigameRating
{
    Fail,
    Success,
    Perfect
}